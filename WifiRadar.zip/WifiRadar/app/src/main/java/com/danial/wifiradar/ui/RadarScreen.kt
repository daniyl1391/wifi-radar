package com.danial.wifiradar.ui

import android.Manifest
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.danial.wifiradar.data.WifiNetwork
import com.danial.wifiradar.ui.theme.RadarBackground
import com.danial.wifiradar.ui.theme.RadarTextMuted
import com.danial.wifiradar.ui.theme.RadarTextSecondary
import com.danial.wifiradar.util.PermissionHelper
import com.danial.wifiradar.viewmodel.RadarViewModel

private enum class RadarTab { RADAR, LIST }

@Composable
fun RadarScreen() {
    val context = LocalContext.current
    val viewModel: RadarViewModel = viewModel()
    val uiState by viewModel.uiState.collectAsState()

    var selectedNetwork by remember { mutableStateOf<WifiNetwork?>(null) }
    var tab by remember { mutableStateOf(RadarTab.RADAR) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        val granted = results[Manifest.permission.ACCESS_FINE_LOCATION] == true
        viewModel.onPermissionResult(granted)
    }

    LaunchedEffect(Unit) {
        if (PermissionHelper.hasAllPermissions(context)) {
            viewModel.onPermissionResult(true)
        } else {
            permissionLauncher.launch(PermissionHelper.requiredPermissions)
        }
    }

    Scaffold(containerColor = RadarBackground) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Wifi Radar", modifier = Modifier.padding(top = 8.dp))
            Text(
                "فاصله‌ها تقریبی و بر اساس قدرت سیگنالن، نه اندازه‌گیری دقیق",
                color = RadarTextMuted,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            when {
                !uiState.hasPermission -> {
                    PermissionRequiredView {
                        permissionLauncher.launch(PermissionHelper.requiredPermissions)
                    }
                }
                !uiState.isWifiEnabled -> {
                    WifiDisabledView {
                        context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                    }
                }
                else -> {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(vertical = 8.dp)
                    ) {
                        FilterChip(
                            selected = tab == RadarTab.RADAR,
                            onClick = { tab = RadarTab.RADAR },
                            label = { Text("رادار") }
                        )
                        FilterChip(
                            selected = tab == RadarTab.LIST,
                            onClick = { tab = RadarTab.LIST },
                            label = { Text("لیست") }
                        )
                    }

                    if (uiState.networks.isEmpty()) {
                        EmptyStateView()
                    } else if (tab == RadarTab.RADAR) {
                        RadarCanvas(
                            networks = uiState.networks,
                            onNetworkClick = { selectedNetwork = it },
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        ListScreen(uiState.networks) { selectedNetwork = it }
                    }

                    Text(
                        "${uiState.networks.size} شبکه شناسایی شد",
                        color = RadarTextSecondary,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            }
        }
    }

    selectedNetwork?.let { network ->
        NetworkDetailSheet(network = network, onDismiss = { selectedNetwork = null })
    }
}

@Composable
private fun PermissionRequiredView(onRequestPermission: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("برای اسکن وای‌فای به مجوز موقعیت مکانی نیاز داریم")
        Button(onClick = onRequestPermission, modifier = Modifier.padding(top = 12.dp)) {
            Text("اجازه دادن")
        }
    }
}

@Composable
private fun WifiDisabledView(onOpenSettings: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("وای‌فای گوشی خاموشه")
        Button(onClick = onOpenSettings, modifier = Modifier.padding(top = 12.dp)) {
            Text("باز کردن تنظیمات وای‌فای")
        }
    }
}

@Composable
private fun EmptyStateView() {
    Text("هنوز شبکه‌ای پیدا نشده... در حال اسکن", color = RadarTextMuted)
}
