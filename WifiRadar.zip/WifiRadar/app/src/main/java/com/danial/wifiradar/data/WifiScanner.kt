package com.danial.wifiradar.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.WifiManager
import androidx.core.content.ContextCompat
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow

/**
 * لایه‌ی مسئول اسکن وای‌فای.
 *
 * نکته‌ی مهم درباره‌ی throttling: از اندروید ۹ (API 28) به بعد،
 * سیستم‌عامل تعداد فراخوانی‌های startScan() رو برای اپ‌های فورگراند
 * عادی به حداکثر ۴ بار در هر ۲ دقیقه محدود می‌کنه. این یعنی حتی اگه
 * ما هر ثانیه startScan صدا بزنیم، نتیجه‌ی واقعی خیلی کندتر آپدیت
 * می‌شه. به همین دلیل، ما اسکن واقعی رو هر ۱۵ ثانیه صدا می‌زنیم و
 * UI رو به‌جاش با آخرین نتایج موجود به‌روزرسانی می‌کنیم.
 */
class WifiScanner(private val context: Context) {

    private val wifiManager: WifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    companion object {
        const val REAL_SCAN_INTERVAL_MS = 15_000L
    }

    fun isWifiEnabled(): Boolean = wifiManager.isWifiEnabled

    /** درخواست یک اسکن جدید از سیستم‌عامل (ممکنه throttle بشه) */
    fun requestScan() {
        wifiManager.startScan()
    }

    /** آخرین نتایج موجود در کش سیستم رو برمی‌گردونه، بدون درخواست اسکن جدید */
    fun getLastResults(): List<WifiNetwork> {
        val hasPermission = ContextCompat.checkSelfPermission(
            context, android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED

        if (!hasPermission) return emptyList()

        return wifiManager.scanResults.map { result ->
            WifiNetwork(
                ssid = result.SSID.ifBlank { "(بدون نام)" },
                bssid = result.BSSID,
                rssi = result.level,
                frequencyMhz = result.frequency,
                timestamp = System.currentTimeMillis(),
                angleDeg = stableAngleFromBssid(result.BSSID)
            )
        }.sortedByDescending { it.rssi }
    }

    /**
     * یک Flow که هر بار نتایج اسکن سیستم آماده بشه (broadcast می‌رسه)
     * لیست جدید رو emit می‌کنه.
     */
    fun scanResultsFlow() = callbackFlow {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                trySend(getLastResults())
            }
        }
        val filter = IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        ContextCompat.registerReceiver(
            context, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED
        )
        // ارسال نتایج فعلی به‌محض شروع، تا کاربر منتظر اولین broadcast نمونه
        trySend(getLastResults())

        awaitClose { context.unregisterReceiver(receiver) }
    }
}
