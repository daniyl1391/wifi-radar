package com.danial.wifiradar.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.drawscope.Stroke
import com.danial.wifiradar.data.WifiNetwork
import com.danial.wifiradar.ui.theme.RadarBlue
import com.danial.wifiradar.ui.theme.RadarBorder
import com.danial.wifiradar.ui.theme.rssiToColor
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.hypot

/**
 * هر نقطه‌ی رادار از روی RSSI (فاصله‌ی شعاعی) و angleDeg (صرفاً برای
 * پخش بصری، بدون معنای جهت واقعی) محاسبه می‌شه.
 */
@Composable
fun RadarCanvas(
    networks: List<WifiNetwork>,
    onNetworkClick: (WifiNetwork) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "radar")
    val sweepAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "sweep"
    )
    val pulseProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "pulse"
    )

    // موقعیت‌های محاسبه‌شده‌ی نقاط، برای تشخیص تپ کاربر نگه داشته می‌شن
    var blipPositions by remember { mutableStateOf(mapOf<WifiNetwork, Offset>()) }

    Box(modifier = modifier) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .pointerInput(networks) {
                    detectTapGestures { tapOffset ->
                        val hit = blipPositions.entries.minByOrNull {
                            hypot(
                                (it.value.x - tapOffset.x).toDouble(),
                                (it.value.y - tapOffset.y).toDouble()
                            )
                        }
                        hit?.let { (network, pos) ->
                            val dist = hypot(
                                (pos.x - tapOffset.x).toDouble(),
                                (pos.y - tapOffset.y).toDouble()
                            )
                            if (dist < 40) onNetworkClick(network)
                        }
                    }
                }
        ) {
            val center = Offset(size.width / 2, size.height / 2)
            val maxRadius = min(size.width, size.height) / 2 - 20f

            // حلقه‌های هم‌مرکز
            listOf(0.33f, 0.66f, 1f).forEach { fraction ->
                drawCircle(
                    color = RadarBorder,
                    radius = maxRadius * fraction,
                    center = center,
                    style = Stroke(width = 1.5f)
                )
            }

            // خطوط صلیبی
            drawLine(RadarBorder, Offset(center.x - maxRadius, center.y), Offset(center.x + maxRadius, center.y), 1.5f)
            drawLine(RadarBorder, Offset(center.x, center.y - maxRadius), Offset(center.x, center.y + maxRadius), 1.5f)

            // خط اسکن چرخشی
            val sweepRad = Math.toRadians(sweepAngle.toDouble() - 90)
            val sweepEnd = Offset(
                center.x + (maxRadius * cos(sweepRad)).toFloat(),
                center.y + (maxRadius * sin(sweepRad)).toFloat()
            )
            drawLine(
                color = com.danial.wifiradar.ui.theme.RadarGreen.copy(alpha = 0.7f),
                start = center,
                end = sweepEnd,
                strokeWidth = 3f
            )

            // نقطه‌ی مرکزی (خود کاربر)
            drawCircle(RadarBlue, radius = 8f, center = center)

            // نقاط شبکه‌ها
            val newPositions = mutableMapOf<WifiNetwork, Offset>()
            networks.forEach { network ->
                val norm = network.signalStrengthNormalized() // ۰ ضعیف تا ۱ قوی
                val radiusFraction = 1f - norm // قوی‌تر = نزدیک‌تر به مرکز
                val r = 24f + radiusFraction * (maxRadius - 24f)
                val rad = Math.toRadians(network.angleDeg.toDouble())
                val pos = Offset(
                    center.x + (r * cos(rad)).toFloat(),
                    center.y + (r * sin(rad)).toFloat()
                )
                newPositions[network] = pos

                val color = rssiToColor(network.rssi)

                // افکت پالس/موج
                drawCircle(
                    color = color.copy(alpha = (1f - pulseProgress) * 0.5f),
                    radius = 6f + pulseProgress * 24f,
                    center = pos
                )
                // گلوی ملایم برای سیگنال قوی
                if (norm > 0.6f) {
                    drawCircle(color.copy(alpha = 0.25f), radius = 14f, center = pos)
                }
                drawCircle(color, radius = 6f, center = pos)
            }
            blipPositions = newPositions
        }
    }
}
