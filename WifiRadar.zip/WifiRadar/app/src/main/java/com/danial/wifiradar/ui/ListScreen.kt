package com.danial.wifiradar.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.danial.wifiradar.data.WifiNetwork
import com.danial.wifiradar.ui.theme.RadarSurface
import com.danial.wifiradar.ui.theme.rssiToColor

@Composable
fun ListScreen(networks: List<WifiNetwork>, onNetworkClick: (WifiNetwork) -> Unit) {
    LazyColumn(modifier = Modifier.padding(horizontal = 16.dp)) {
        items(networks.sortedByDescending { it.rssi }) { network ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .background(RadarSurface, RoundedCornerShape(10.dp))
                    .clickable { onNetworkClick(network) }
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(network.ssid)
                Text(
                    "${network.rssi} dBm",
                    color = rssiToColor(network.rssi),
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
