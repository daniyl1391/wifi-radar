package com.danial.wifiradar.data

/**
 * مدل داده‌ی یک شبکه‌ی وای‌فای شناسایی‌شده.
 * angleDeg بر اساس هش BSSID محاسبه می‌شه و صرفاً برای پخش بصری روی
 * رادار استفاده می‌شه — هیچ معنای جهت فیزیکی واقعی نداره، چون گوشی
 * با یک آنتن امکان تشخیص جهت سیگنال رو نداره.
 */
data class WifiNetwork(
    val ssid: String,
    val bssid: String,
    val rssi: Int,          // dBm، معمولاً بین -30 (خیلی قوی) تا -90 (خیلی ضعیف)
    val frequencyMhz: Int,
    val timestamp: Long,
    val angleDeg: Float
) {
    val band: String get() = if (frequencyMhz > 3000) "5GHz" else "2.4GHz"

    /** نرمال‌سازی RSSI به بازه‌ی ۰ (ضعیف) تا ۱ (قوی) */
    fun signalStrengthNormalized(): Float {
        val clamped = rssi.coerceIn(-90, -30)
        return (clamped + 90) / 60f
    }
}

/**
 * تابع هش پایدار برای تبدیل BSSID به یک زاویه‌ی ثابت (۰ تا ۳۶۰ درجه).
 * همون شبکه همیشه همون زاویه رو می‌گیره تا موقعیتش بین رفرش‌ها نپره.
 */
fun stableAngleFromBssid(bssid: String): Float {
    var hash = 0
    for (c in bssid) {
        hash = (hash * 31 + c.code) % 360
    }
    if (hash < 0) hash += 360
    return hash.toFloat()
}
