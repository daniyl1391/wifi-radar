package com.danial.wifiradar.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

val RadarBackground = Color(0xFF0A0D0A)
val RadarSurface = Color(0xFF101A13)
val RadarBorder = Color(0xFF1F3A28)
val RadarGreen = Color(0xFF3EE06A)
val RadarYellow = Color(0xFFE0C23E)
val RadarRed = Color(0xFFE0603E)
val RadarBlue = Color(0xFF6AB7FF)
val RadarTextPrimary = Color(0xFFD0F0D8)
val RadarTextSecondary = Color(0xFF9AC9A8)
val RadarTextMuted = Color(0xFF6A9A78)

val MonoFont = FontFamily.Monospace

private val DarkColors = darkColorScheme(
    background = RadarBackground,
    surface = RadarSurface,
    primary = RadarGreen,
    secondary = RadarBlue,
    onBackground = RadarTextPrimary,
    onSurface = RadarTextPrimary
)

@Composable
fun WifiRadarTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        content = content
    )
}

fun rssiToColor(rssi: Int): Color = when {
    rssi >= -50 -> RadarGreen
    rssi >= -70 -> RadarYellow
    else -> RadarRed
}
