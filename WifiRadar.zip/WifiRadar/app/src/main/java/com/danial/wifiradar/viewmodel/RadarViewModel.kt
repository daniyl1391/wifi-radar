package com.danial.wifiradar.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.danial.wifiradar.data.WifiNetwork
import com.danial.wifiradar.data.WifiScanner
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class RadarUiState(
    val networks: List<WifiNetwork> = emptyList(),
    val isWifiEnabled: Boolean = true,
    val hasPermission: Boolean = false,
    val isScanning: Boolean = false
)

class RadarViewModel(application: Application) : AndroidViewModel(application) {

    private val scanner = WifiScanner(application)

    private val _uiState = MutableStateFlow(RadarUiState())
    val uiState: StateFlow<RadarUiState> = _uiState.asStateFlow()

    private var loopStarted = false

    fun onPermissionResult(granted: Boolean) {
        _uiState.value = _uiState.value.copy(hasPermission = granted)
        if (granted) startScanLoop()
    }

    fun checkWifiEnabled() {
        _uiState.value = _uiState.value.copy(isWifiEnabled = scanner.isWifiEnabled())
    }

    /**
     * حلقه‌ی اصلی اسکن: هر ۱۵ ثانیه یک اسکن واقعی از سیستم درخواست
     * می‌کنه (طبق محدودیت throttling اندروید)، ولی چون scanResultsFlow
     * به broadcast سیستم گوش می‌ده، هر بار نتیجه‌ی واقعی آماده بشه
     * (حتی زودتر از ۱۵ ثانیه، اگه اپ دیگه‌ای اسکن زده باشه) UI آپدیت می‌شه.
     */
    private fun startScanLoop() {
        if (loopStarted) return
        loopStarted = true

        viewModelScope.launch {
            scanner.scanResultsFlow().collect { networks ->
                _uiState.value = _uiState.value.copy(
                    networks = networks,
                    isScanning = false
                )
            }
        }

        viewModelScope.launch {
            while (true) {
                checkWifiEnabled()
                if (_uiState.value.isWifiEnabled) {
                    _uiState.value = _uiState.value.copy(isScanning = true)
                    scanner.requestScan()
                }
                delay(WifiScanner.REAL_SCAN_INTERVAL_MS)
            }
        }
    }
}
