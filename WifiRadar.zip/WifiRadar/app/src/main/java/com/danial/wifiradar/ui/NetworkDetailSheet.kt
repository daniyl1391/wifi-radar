package com.danial.wifiradar.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.danial.wifiradar.data.WifiNetwork
import com.danial.wifiradar.ui.theme.MonoFont
import com.danial.wifiradar.ui.theme.RadarTextSecondary
import com.danial.wifiradar.ui.theme.rssiToColor

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkDetailSheet(network: WifiNetwork, onDismiss: () -> Unit) {
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(network.ssid, fontWeight = FontWeight.Medium, fontSize = androidx.compose.ui.unit.TextUnit.Unspecified)
            Divider(modifier = Modifier.padding(vertical = 12.dp))
            DetailRow("BSSID", network.bssid)
            DetailRow("RSSI", "${network.rssi} dBm")
            DetailRow("فرکانس", "${network.frequencyMhz} MHz")
            DetailRow("باند", network.band)
            DetailRow("قدرت سیگنال", rssiLabel(network.rssi))
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = RadarTextSecondary, fontSize = androidx.compose.ui.unit.TextUnit.Unspecified)
        Text(value, fontFamily = MonoFont)
    }
}

private fun rssiLabel(rssi: Int): String = when {
    rssi >= -50 -> "قوی"
    rssi >= -70 -> "متوسط"
    else -> "ضعیف"
}
